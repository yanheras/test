# Bundle example for the data parameter of the risk-gap operation - Da Vinci Risk Adjustment Implementation Guide v3.0.0-ballot

## Example Bundle: Bundle example for the data parameter of the risk-gap operation



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ra-riskgap-data1",
  "meta" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/instance-name",
      "valueString" : "Bundle example for the data parameter of the risk-gap operation"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/instance-description",
      "valueMarkdown" : "This is a Bundle example includes referenced resources by parameters of the risk-gap operation."
    }]
  },
  "language" : "en",
  "identifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:97935a18-56b7-490b-a12c-9dac8995f6d5"
  },
  "type" : "collection",
  "timestamp" : "2026-01-07T06:17:58.172+00:00",
  "entry" : [{
    "fullUrl" : "http://example.org/fhir/Patient/ra-patient01",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "ra-patient01",
      "meta" : {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/instance-name",
          "valueString" : "Patient Example01"
        },
        {
          "url" : "http://hl7.org/fhir/StructureDefinition/instance-description",
          "valueMarkdown" : "This is an example patient that uses the US Core Patient profile. The example patient name is Eve Everywoman."
        }],
        "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-patient|7.0.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div class=\"hapiHeaderText\"><a name=\"Patient_ra-patient01\"> </a>Eve <b>EVERYWOMAN </b></div><table class=\"hapiPropertyTable\"><tbody><tr><td>Identifier</td><td>12345</td></tr><tr><td>Address</td><td><span>2222 Home Street </span><br/><span>Ann Arbor </span><span>MI </span><span>USA </span></td></tr><tr><td>Date of birth</td><td><span>16 January 1975</span></td></tr></tbody></table></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/us/core/StructureDefinition/us-core-birthsex",
        "valueCode" : "F"
      },
      {
        "extension" : [{
          "url" : "ombCategory",
          "valueCoding" : {
            "system" : "urn:oid:2.16.840.1.113883.6.238",
            "code" : "2106-3",
            "display" : "White"
          }
        },
        {
          "url" : "text",
          "valueString" : "White"
        }],
        "url" : "http://hl7.org/fhir/us/core/StructureDefinition/us-core-race"
      },
      {
        "extension" : [{
          "url" : "ombCategory",
          "valueCoding" : {
            "system" : "urn:oid:2.16.840.1.113883.6.238",
            "code" : "2186-5",
            "display" : "Not Hispanic or Latino"
          }
        },
        {
          "url" : "text",
          "valueString" : "Not Hispanic or Latino"
        }],
        "url" : "http://hl7.org/fhir/us/core/StructureDefinition/us-core-ethnicity"
      }],
      "identifier" : [{
        "use" : "usual",
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "MR",
            "display" : "Medical record number"
          }]
        },
        "system" : "http://example.org/hospital-davinci",
        "value" : "12345"
      }],
      "active" : true,
      "name" : [{
        "use" : "official",
        "family" : "Everywoman",
        "given" : ["Eve"]
      }],
      "gender" : "female",
      "birthDate" : "1975-01-16",
      "deceasedBoolean" : false,
      "address" : [{
        "use" : "home",
        "line" : ["2222 Home Street"],
        "city" : "Ann Arbor",
        "state" : "MI",
        "postalCode" : "99999",
        "country" : "USA"
      }],
      "maritalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-MaritalStatus",
          "code" : "M",
          "display" : "Married"
        }]
      },
      "communication" : [{
        "language" : {
          "coding" : [{
            "system" : "urn:ietf:bcp:47",
            "code" : "en-US",
            "display" : "English (United States)"
          }]
        },
        "preferred" : true
      }]
    }
  },
  {
    "fullUrl" : "http://example.org/fhir/Encounter/ra-encounter03pat01",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "ra-encounter03pat01",
      "meta" : {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/instance-name",
          "valueString" : "Encounter with Dr Howell on 20210714 for Patient 03"
        },
        {
          "url" : "http://hl7.org/fhir/StructureDefinition/instance-description",
          "valueMarkdown" : "This is Encounter with Dr Howell on 20210714 for Patient 03."
        }],
        "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-encounter|7.0.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_ra-encounter03pat01\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter ra-encounter03pat01</b></p><a name=\"ra-encounter03pat01\"> </a><a name=\"hcra-encounter03pat01\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.org/fhir/us/core/STU7/StructureDefinition-us-core-encounter.html\">US Core Encounter Profileversion: null7.0.0)</a></p></div><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.0.1/CodeSystem-v3-ActCode.html#v3-ActCode-AMB\">ActCode: AMB</a> (ambulatory)</p><p><b>type</b>: <span title=\"Codes:{http://www.ama-assn.org/go/cpt 99215}\">Office Visit, High Complexity</span></p><p><b>subject</b>: <a href=\"Patient-ra-patient01.html\">Eve Everywoman (official) Female, DoB: 1975-01-16 ( Medical record number: 12345 (use: usual, ))</a></p><h3>Participants</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Individual</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Practitioner-ra-prac01pat01.html\">Practitioner Harold Hippocrates </a></td></tr></table><p><b>period</b>: 2021-09-26 --&gt; 2021-09-26</p><blockquote><p><b>diagnosis</b></p><p><b>condition</b>: <a href=\"Condition-ra-condition03pat01.html\">Condition Chronic obstructive pulmonary disease with (acute) exacerbation</a></p></blockquote><blockquote><p><b>diagnosis</b></p><p><b>condition</b>: <a href=\"Condition-ra-condition10pat01.html\">Condition Long term (current) use of insulin</a></p></blockquote><blockquote><p><b>diagnosis</b></p><p><b>condition</b>: <a href=\"Condition-ra-condition18pat01.html\">Condition Longstanding persistent atrial fibrillation</a></p></blockquote><blockquote><p><b>diagnosis</b></p><p><b>condition</b>: <a href=\"Condition-ra-condition33pat01.html\">Condition Respiratory arrest</a></p></blockquote><p><b>serviceProvider</b>: <a href=\"Organization-ra-org01pat01.html\">Organization Community Urgent Care</a></p></div>"
      },
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "AMB",
        "display" : "ambulatory"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://www.ama-assn.org/go/cpt",
          "code" : "99215"
        }],
        "text" : "Office Visit, High Complexity"
      }],
      "subject" : {
        "reference" : "Patient/ra-patient01"
      },
      "participant" : [{
        "individual" : {
          "reference" : "Practitioner/ra-prac01pat01"
        }
      }],
      "period" : {
        "start" : "2021-09-26",
        "end" : "2021-09-26"
      },
      "diagnosis" : [{
        "condition" : {
          "reference" : "Condition/ra-condition03pat01"
        }
      },
      {
        "condition" : {
          "reference" : "Condition/ra-condition10pat01"
        }
      },
      {
        "condition" : {
          "reference" : "Condition/ra-condition18pat01"
        }
      },
      {
        "condition" : {
          "reference" : "Condition/ra-condition33pat01"
        }
      }],
      "serviceProvider" : {
        "reference" : "Organization/ra-org01pat01"
      }
    }
  }]
}

```
