#  - Your User Friendly Name for MyIG Here v0.2.0

## : 



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "h1",
  "language" : "en",
  "type" : "collection",
  "entry" : [{
    "fullUrl" : "http://somewhere.org/fhir/uv/myig/Provenance/h1-1",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "h1-1",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Provenance_h1-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance h1-1</b></p><a name=\"h1-1\"> </a><a name=\"hch1-1\"> </a><p>Provenance for <a href=\"StructureDefinition-myObservation.html\">StructureDefinition My Observation Profile</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2015-11-30</td></tr><tr><td>Recorded</td><td>2020-01-01 00:00:00+0000</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-DataOperation UPDATE}\">revise</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>Type</b></td><td><b>who</b></td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type author}\">Author</span></td><td>Rob Hausam</td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type verifier}\">Verifier</span></td><td>Vocab</td></tr></table></div></div>"
      },
      "target" : [{
        "reference" : "StructureDefinition/myObservation"
      }],
      "occurredDateTime" : "2015-11-30",
      "recorded" : "2020-01-01T00:00:00.000Z",
      "reason" : [{
        "text" : "Add \"conductible\" property to ActRelationshipType and ParticipationType codes.for ContextConduction RIM Change. And create Concept domain CodeSystem and ValueSet for ContextConductionStyle"
      }],
      "activity" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-DataOperation",
          "code" : "UPDATE"
        }]
      },
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "author"
          }]
        },
        "who" : {
          "display" : "Rob Hausam"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "verifier"
          }]
        },
        "who" : {
          "display" : "Vocab"
        }
      }]
    }
  }]
}

```
